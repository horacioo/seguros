<section id="slideDepoimentos">

    
<header>
    <h2>Depoimentos</h2>
</header>

    <!--<div class='custom-prev'><img src='<?php echo tema; ?>/partes/slideProdutos/imagens/setaEsquerda.png'></div>
    <div class='custom-next'><img src='<?php echo tema; ?>/partes/slideProdutos/imagens/setaDireita.png'></div>-->

    <ul>

            <!---------------------------------------------------------->
            <li>
                <h2>Reginaldo Rodrigues</h2>
                <p>
                "Ficou bonito o novo visual, sem contar na variedade e produtos mais em conta!"</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Luiz Miranda</h2>
                <p>"Serviços de excelente qualidade e equipe bem atenciosa"</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Ana Seabra</h2>
                <p>"Prestação de serviço com qualidade e excelente atendimento dos funcionários."</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Leonardo Souza Ribeiro</h2>
                <p>"Bons preço e excelente retorno de orçamento."</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>José Lima </h2>
                <p>"Tem ótimos preços e bons profissionais."</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Paula Merlim</h2>
                <p>"Preço ótimo e Atendimento diferenciado."</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Luiz Albamonte</h2>
                <p>"Bom atendimento,  ótimo preço."</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Romualdo Júnior</h2>
                <p>"Vc encontra tudo para impressão entre outras coisas!"</p>
            </li>
            <!---------------------------------------------------------->
            <li>
                <h2>Fabrizio Cosentino</h2>
                <p>"Ótimo atendimento. Procurar Alex"</p>
            </li>
            <!---------------------------------------------------------->

           
            
             

    </ul>
</section>

