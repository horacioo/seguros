jQuery(document).ready(function () {
  
  
  
  
  // Função para verificar a largura da tela e aplicar o comportamento
  function verificaLargura() {
    var larguraTela = window.innerWidth;

    if (larguraTela < 768) {
      //alert("tudo bem com você "+larguraTela); 
      AbreMenu();
      FechaMenu();
    } else {
      // Remove o menu e a classe se a tela for maior que 768 ao redimensionar
      jQuery("#menu").show();
      jQuery("#fundoMenu").removeClass("fundo");
    }
  }





  // Verifica a largura da tela no carregamento inicial
  verificaLargura();

  // Verifica a largura da tela toda vez que a janela for redimensionada
  jQuery(window).resize(function () {
    verificaLargura();
  });
});

function AbreMenu() {
  jQuery("#menu").hide();
  jQuery("#icon")
    .off("click")
    .on("click", function () {
      // Evita adicionar múltiplos eventos
      jQuery("#fundoMenu").addClass("fundo");
      jQuery("#menu").show();
    });
}

function FechaMenu() {
  // Usar delegação de eventos para garantir que o clique no fundo funcione
  jQuery(document)
    .off("click", ".fundo")
    .on("click", ".fundo", function () {
      // Evita múltiplos eventos
      jQuery("#menu").hide();
      jQuery("#fundoMenu").removeClass("fundo");
    });
}
