<div class="mobile" id="fundoMenu"></div>
<div class="mobile" id="icon">

    <img alt="icone do menu" width="70" height="70" id="iconeDoMenu" src="<?php echo tema; ?>/partes/menu/imagens/menuIcon2.svg">

</div>

<nav id='menu'>
    <?php wp_nav_menu(); ?>
    <!--ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Institucional</a></li>
        <li><a href="#">Serviços</a></li>
        <li><a href="#">Equipamentos</a></li>
        <li><a href="#">Portifólio</a></li>
        <li><a href="#">Contato</a></li>
    </ul>-->
</nav>