<main id="paginadeResultados">
    <h1>Resultados da pesquisa para: <?php echo get_search_query(); ?></h1>

    <?php if (have_posts()) : ?>
        <ul>
            <?php while (have_posts()) : the_post(); ?>
                <li>

                    <?php $ID = get_the_ID();
                    /********************************************************/
                    $image_id = get_post_thumbnail_id($ID);
                    $image_path = get_attached_file($image_id);
                    $thumb = get_the_post_thumbnail_url($ID);
                    $tamanhos = [

                        ['largura' => 392, 'altura' => 160,   'qualidade' => 80],
                        ['largura' => 400, 'altura' => 350,   'qualidade' => 80],
                        ['largura' => 320, 'altura' => 300,   'qualidade' => 80],
                    ];
                    $imagens = reduzirImagem($image_path, $tamanhos);
                    /********************************************************/
                    ?>

                    <a href="<?php the_permalink(); ?>">


                        <picture>
                            <source media="(min-width: 2px) and (max-width: 319px)" srcset="<?= $imagens['urls']['320x300'] ?>">
                            <source media="(min-width: 320px) and (max-width: 500px)" srcset="<?= $imagens['urls']['400x350'] ?>">
                            <source media="(min-width: 501px)" srcset="<?= $imagens['urls']['392x160'] ?>">
                            <img alt="imagem do produto" width="219" height="134" src="<?= $imagens['urls']['392x160'] ?>">
                        </picture>


                        <h2><?php the_title(); ?></h2>
                        <p><?php the_excerpt(); ?></p>
                    </a>



                </li>
            <?php endwhile; ?>
        </ul>
    <?php else : ?>
        <p>Nenhum resultado encontrado.</p>
    <?php endif; ?>
</main>