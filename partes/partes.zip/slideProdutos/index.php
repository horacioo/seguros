<section id="Slide">

    <div class='custom-prev'><img alt='controle do slide' height="20" width="20" src='<?php echo tema; ?>/partes/slideProdutos/imagens/setaEsquerda.png'></div>
    <div class='custom-next'><img alt='controle do slide' height="20" width="20" src='<?php echo tema; ?>/partes/slideProdutos/imagens/setaDireita.png'></div>

    <ul id="slideInter">

        
        <?php
        $tamanhos = [
            ['largura' => 800, 'altura' => 600, 'qualidade' => 10],
            ['largura' => 768, 'altura' => 500,   'qualidade' => 20],
            ['largura' => 425, 'altura' => 350,   'qualidade' => 20],
            ['largura' => 375, 'altura' => 200,   'qualidade' => 20],
            ['largura' => 320, 'altura' => 200,   'qualidade' => 20],
        ];
       $imagens= reduzirImagem(get_template_directory() . "/partes/slideProdutos/imagens/imagem1.jpg", $tamanhos);
        

      /// print_r($imagens['urls']);
        ?>
        <!---------------------------------------------------------->
        <li>
            <picture>
                <source media="(min-width:1px) and (max-width:320px)" srcset="<?php echo tema; ?>/partes/slideProdutos/imagens/reduzidas/imagem1_320X200.avif">
                <source media="(min-width:321px) and (max-width:374px)" srcset="<?php echo tema; ?>/partes/slideProdutos/imagens/reduzidas/imagem1_375X200.avif">
                <source media="(min-width:375px) and (max-width:425px)" srcset="<?php echo tema; ?>/partes/slideProdutos/imagens/reduzidas/imagem1_425X350.avif">
                <source media="(min-width:426px) and (max-width:768px)" srcset="<?php echo tema; ?>/partes/slideProdutos/imagens/reduzidas/imagem1_768X500.avif">
                <img alt="imagem 1" width="317" height="317" src="<?php echo tema; ?>/partes/slideProdutos/imagens/reduzidas/imagem1_800X600.avif">

            </picture>

            <header>
                <h2>
                    Precisa de um orçamento
                    ou gostaria de alguma
                    informação que não
                    encontrou, clique no
                    nosso link de whatsapp, nos chame e
                    conversarmos agora mesmo!
                </h2>
            </header>
        </li>
        <!---------------------------------------------------------->



    </ul>

    <img id='cores' alt="representação das cores usadas em gráficas" width="200" height="28" src="<?php echo tema; ?>/img/marcaCores.svg">
</section>