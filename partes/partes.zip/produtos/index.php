<section id="produtos">
    <header>
        <h2>Nossos Produtos</h2>
    </header>



    <?php

    $parent_id = 11; // Substitua pelo ID da sua página "Produtos"

    // Obter as páginas filhas
    $children = get_children(array(
        'post_parent' => $parent_id,
        'post_type'   => 'page',
        'orderby'     => 'menu_order',
        'order'       => 'ASC',
    ));



    // Verificar se existem páginas filhas
    if ($children) {
        echo '<ul>';
        foreach ($children as $child) {

            /********************************************************/
            //$thumb = get_the_post_thumbnail_url($child->ID, 'home1');
            //$thumb2 = get_the_post_thumbnail_url($child->ID, 'home2');
            //$thumb3 = get_the_post_thumbnail_url($child->ID, 'home3');
            //$thumb4 = get_the_post_thumbnail_url($child->ID, 'home4');
            /********************************************************/

            /**************************************************************/
            $image_id = get_post_thumbnail_id($child->ID); // Obter ID do thumbnail
            $image_path = get_attached_file($image_id); // Caminho absoluto da image
            /********************************************************/

            $thumb = get_the_post_thumbnail_url($child->ID);

           
            /******************************************************************************/
            $tamanhos = [
               
                ['largura' => 411, 'altura' => 411,   'qualidade' => 50],
                ['largura' => 425, 'altura' => 300,   'qualidade' => 40],
            ];
            $imagens = reduzirImagem($image_path, $tamanhos);

            /*******************************************************************************/


     

            echo '<li>
                  <picture> 
                
<!--------------------------------------------------->
                  <source media="(min-width:320px) and (max-width:425px)" srcset="' . $imagens['urls']['425x300'] . '">
                  <source media="(min-width:1025px) and (max-width:1366px)" srcset="' . $imagens['urls']['411x411'] . '">
                  <source media="(min-width:1367px) and (max-width:1440px)" srcset="' . $imagens['urls']['411x411'] . '">
                  <source media="(min-width:1441px) and (max-width:2000px)" srcset="' . $imagens['urls']['411x411'] . '">
<!--------------------------------------------------->

                  <img alt="imagem do produto" width="219" height="134" src="' . $imagens['urls']['411x411'] . '" class="thumb">
                  </picture>
                  
                  <a href="' . get_permalink($child->ID) . '">' . get_the_title($child->ID) . '</a></li>';
                  
        }
        echo '</ul>';
    } else {
        echo '-';
    }

    ?>
</section>