<section id="ContatoInfo">

    <div id="texto">
        <p> 
            Pronto para levar seus projetos gráficos ao próximo nível?
            Entre em contato agora mesmo e descubra como podemos
            transformar suas ideias em impressões de alta qualidade! Seja por
            WhatsApp, e-mail, telefone ou redes sociais, nossa equipe está
            pronta para oferecer soluções gráficas rápidas e personalizadas,
            com todo o cuidado que o seu projeto merece.
        </p>

        <p>
            <strong>
                Clique no link que for mais fácil para você e comece a criar impressões profissionais de verdade! Não perca tempo, fale conosco hoje e veja como podemos fazer a diferença na qualidade dos seus materiais gráficos!
            </strong>
        </p>

    </div>

    <div id="logos">
        <a href="tel:+2122623040"><img class='element' alt="icone de telefone" id="tel" src="<?php echo tema ?>/partes/contatos_/imagem/telefone.png" width="30" height="30"></a>
        <a href="https://www.instagram.com/print.cad/" target="_blank"><img class='element'  alt="icone de instagram" id="instagram" src="<?php echo tema ?>/partes/contatos_/imagem/instagram.png" width="30" height="30"></a>
        <a href="https://www.facebook.com/fanpageprintcad" target="_blank"><img class='element'  alt="icone de facebook" id="face" src="<?php echo tema ?>/partes/contatos_/imagem/facebook.png" width="30" height="30"></a>
        <a href="https://api.whatsapp.com/send?phone=5521971385918" target="_blank"><img class='element'  alt="icone de whatsapp"id="whats" src="<?php echo tema ?>/partes/contatos_/imagem/whats.png" width="30" height="30"></a>
        <a href="mailto:impressao.printcadcopias@gmail.com"><img class='element'  alt="icone de email" id="mail" src="<?php echo tema ?>/partes/contatos_/imagem/mail.png" width="30" height="30"></a>
    </div>

    <img id="rgb" alt="icone de cores primárias" src="<?php echo tema ?>/partes/contatos_/imagem/Rgb.png" width="30" height="30">
    <img id="cores" alt="cores usadas em gráficas" src="<?php echo tema ?>/partes/contatos_/imagem/cores.svg" width="30" height="30">
</section>


