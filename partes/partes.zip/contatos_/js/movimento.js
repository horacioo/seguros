document.addEventListener('mousemove', function(e) {
    const elements = document.querySelectorAll('.element');

    elements.forEach(el => {
        const rect = el.getBoundingClientRect();
        const elX = rect.left + rect.width / 2; // Centro do elemento
        const elY = rect.top + rect.height / 2;
        const distX = e.clientX - elX; // Distância no eixo X
        const distY = e.clientY - elY; // Distância no eixo Y

        const distance = Math.sqrt(distX * distX + distY * distY); // Distância total

        // Defina uma distância mínima e máxima para o efeito de atração
        const maxDistance = 2000;
        const minDistance = 30; // Distância mínima para evitar o "tremor"

        if (distance < maxDistance && distance > minDistance) {
            // Calcular o movimento com base na proximidade do cursor
            const moveX = (distX / distance) * (maxDistance - distance) / 50;
            const moveY = (distY / distance) * (maxDistance - distance) / 50;

            el.style.transform = `translate(${moveX}px, ${moveY}px)`;
        } else {
            el.style.transform = 'translate(0px, 0px)'; // Volta para a posição original
        }
    });
});