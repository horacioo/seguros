<section id="produtos">
    <header>
        <h2>Nossos Produtos</h2>
    </header>
    
    
    
    <?php

    $parent_id = 11; // Substitua pelo ID da sua página "Produtos"

    // Obter as páginas filhas
    $children = get_children(array(
        'post_parent' => $parent_id,
        'post_type'   => 'page',
        'orderby'     => 'menu_order',
        'order'       => 'ASC',
    ));



    // Verificar se existem páginas filhas
    if ($children) {
        echo '<ul>';
        foreach ($children as $child) {

            /********************************************************/
            $thumb = get_the_post_thumbnail_url($child->ID, 'home1');
            $thumb2 = get_the_post_thumbnail_url($child->ID, 'home2');
            $thumb3 = get_the_post_thumbnail_url($child->ID, 'home3');
            $thumb4 = get_the_post_thumbnail_url($child->ID, 'home4');
            /********************************************************/

            echo '<li>
                  <picture>
                  <source media="(min-width:1025px) and (max-width:1366px)" srcset="' . $thumb2 . '">
                  <source media="(min-width:1367px) and (max-width:1440px)" srcset="' . $thumb3 . '">
                  <source media="(min-width:1441px) and (max-width:2000px)" srcset="' . $thumb4 . '">
                  
                  <img width="219" height="134" src="' . $thumb . '" class="thumb">
                  </picture>

                  <a href="' . get_permalink($child->ID) . '">' . get_the_title($child->ID) . '</a></li>';
        }
        echo '</ul>';
    } else {
        echo '-';
    }

    ?>
</section>