<?php
$titulo_categoria = single_cat_title('', false);
echo '<h1>Categoria : ' . esc_html($titulo_categoria) . '</h1>';
?>




<section id="artigosDessaCategoria">
    <?php
    // Obtém a categoria atual
    $current_category = get_queried_object_id();

    // Modifica a consulta para trazer apenas os posts da categoria atual (exclui subcategorias)
    $args = array(
        'cat' => $current_category, // ID da categoria atual
        'posts_per_page' => 10, // Defina o número de posts que deseja exibir
        'paged' => get_query_var('paged') ? get_query_var('paged') : 1 // Paginação
    );

    $query = new WP_Query($args);

    // Loop para exibir os posts da categoria atual
    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();
    ?>
            <article id="post-<?php the_ID(); ?>"
                <?php post_class(); ?>>

                <?php
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                $ID = get_the_ID();
                /********************************************************/
                $image_id = get_post_thumbnail_id($ID);
                $image_path = get_attached_file($image_id);
                $thumb = get_the_post_thumbnail_url($ID);
                $tamanhos = [

                    ['largura' => 392, 'altura' => 160,   'qualidade' => 80],
                    // ['largura' => 400, 'altura' => 350,   'qualidade' => 80],
                    // ['largura' => 320, 'altura' => 300,   'qualidade' => 80],
                ];
                $imagens = reduzirImagem($image_path, $tamanhos);
                /********************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                /***************************************************************************/
                ?>

                <div class="entry-content">
                    <!-------------------------->
                    <p>
                        <picture >
                            <img alt="imagem do produto" width="219" height="134" src="<?= $imagens['urls']['392x160'] ?>">
                        </picture>
                    </p>
                    <!-------------------------->
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <p><?php echo get_the_date(); ?></p>
                    <p>Escrito por: <?php echo get_the_author(); ?></p>
                    <?php //the_excerpt(); 
                    ?>
                </div>
            </article>
    <?php
        endwhile;
        // Paginação
        the_posts_pagination();
        wp_reset_postdata();
    else :
        echo '<p>Nenhum post encontrado nesta categoria.</p>';
    endif;
    ?>
</section>









<section id="categorias_pai">
    <?php
    // Obtém as categorias associadas ao post atual
    $categories = get_the_category();

    if (! empty($categories)) {
        echo '<ul class="post-categories">';

        // Loop por cada categoria
        foreach ($categories as $category) {
            // Verifica se a categoria tem uma categoria "pai"
            if ($category->parent) {
                // Obtém a categoria pai
                $parent_category = get_category($category->parent);



                // Exibe a categoria pai
                echo '<li>';

                echo 'Categoria Pai: <a href="' . esc_url(get_category_link($parent_category->term_id)) . '">' . esc_html($parent_category->name) . '</a></li>';
            } else {
                // Se não houver categoria pai, apenas exibe a categoria atual
                echo '<li><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
            }
        }

        echo '</ul>';
    }
    ?>
</section>