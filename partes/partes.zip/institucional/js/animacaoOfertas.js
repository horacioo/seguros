    // Função para adicionar a classe 'highlight' aos <picture> um de cada vez
    function addHighlightToPictures() {
        const pictures = document.querySelectorAll('#condicoes li picture');
        let delay = 0;
        pictures.forEach(picture => {
            setTimeout(() => {
                picture.classList.add('highlight');
            }, delay);
            delay += 300; // Aumenta o atraso para o próximo elemento
        });
    }

    // Configura o IntersectionObserver para observar o #condicoes
    const observerOptions = {
        root: null, // O viewport da janela é a área observada
        rootMargin: '0px',
        threshold: 0.5 // O elemento deve estar 50% visível para disparar o callback
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                addHighlightToPictures();
                observer.unobserve(entry.target); // Para de observar após executar
            }
        });
    }, observerOptions);

    // Observa o elemento #condicoes
    const condicoesElement = document.querySelector('#condicoes');
    observer.observe(condicoesElement);