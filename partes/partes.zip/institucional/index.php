<main id="institucional">


    <section>

        <header>
            <h2>Um pouco sobre a PrintCad</h2>
        </header>


        Na PrintCad, nossa missão é simples: garantir que você
        receba serviços de qualidade e dentro do prazo,
        sempre com o foco total na sua satisfação. Sabemos
        que você valoriza rapidez e eficiência, e é por isso que
        estamos aqui para te entregar exatamente isso.
        Nossa equipe é composta por pessoas treinadas e
        qualificadas, que estão sempre prontas para te atender
        da melhor maneira possível. Valorizamos muito cada
        cliente e acreditamos em construir uma relação de
        confiança, onde você se sente à vontade para tirar
        dúvidas e contar com a nossa transparência.
        Trabalhamos com agilidade e temos o conhecimento
        técnico necessário para oferecer soluções que
        realmente funcionam, sem complicação. O resultado?
        Clientes satisfeitos e felizes com o nosso trabalho,
        porque aqui na PrintCad, estamos sempre prontos para
        fazer o que for preciso para te ajudar.

    </section>


    <div>
        <ul id="slideLoja">
            <li>
                <picture>
                    <img alt="imagem do slide" width="550" height="1107" src="<?php echo tema ?>/partes/institucional/imagens/home-1.avif">
                </picture>
            </li>

        </ul>
    </div>

</main>