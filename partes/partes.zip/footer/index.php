<footer style="background-image: url('<?php echo tema ?>/partes/footer/imagem/fundao.svg');">

    <img class='desktop' id="detalheEsquerdaSuperior" src='<?php echo tema ?>/partes/footer/imagem/detalheEsquerdaSuperior.svg'>


    <section class='desktop'>
        <span>
            <h2>Nossos Contatos</h2>
            <ul class="lista">
                <li>Telefone: 1121212</li>
                <li>email: 8383@uol.com.br</li>
                <li>whatsApp: 12323123</li>
            </ul>
        </span>
        <span>
            <h2>Redes Sociais</h2>
            <ul class="lista">
                <li>instagram</li>
                <li>Facebook</li>
                <li>Tik-Tok</li>
            </ul>
        </span>
        <span>
            <h2>Formas de Pagamento</h2>
            <ul class="lista pgto">
                <li><img src='<?php echo tema ?>/partes/footer/imagem/logos_elo.svg'></li>
                <li><img src='<?php echo tema ?>/partes/footer/imagem/logos_mastercard.svg'></li>
                <li><img src='<?php echo tema ?>/partes/footer/imagem/logos_visa.svg'></li>
                <li><img src='<?php echo tema ?>/partes/footer/imagem/simple-icons_americanexpress.svg'></li>
            </ul>
        </span>

        <img id="detalheInferiorDireita" src='<?php echo tema ?>/partes/footer/imagem/detalheInferiorDireita.svg'>

    </section>



    <picture class='desktop'>
        <img src='<?php echo tema ?>/partes/footer/imagem/bicicleta.png'>
    </picture>

    <ul id="rodape" class='desktop'>
        <li><span><a href="mailto:vendas2san@kikos.com.br?subject=informacao+de+produtos&body=quero+informacoes"><img src='<?php echo tema ?>/partes/footer/imagem/envelopeBranco.svg'>e-mail: vendas2san@kikos.com.br</a></span></li>
        <li><span><a href="https://api.whatsapp.com/send?phone=5513981445495"><img src='<?php echo tema ?>/partes/footer/imagem/foneBranco.svg'> Telefone:(13) 98144-5494 </a></span></li>
        <li><span><a href="https://api.whatsapp.com/send?phone=5513981445495" target="_blank"><img src='<?php echo tema ?>/partes/footer/imagem/whatsBranco.svg'> Whats</a></span></li>
    </ul>



    <section id="mobile">
        <a href="tel:13981445494">Ligue <br>agora</a>
        <a href="https://api.whatsapp.com/send?phone=5513981445495" target="_blank">Chame no <br>Whats</a>
        <a href="mailto:vendas2san@kikos.com.br?subject=informacao+de+produtos&body=quero+informacoes" target="_blank">Enviar <br>E-mail</a>
    </section>


</footer>