<section id="MinhasRedesSociais">

    <ul>
        <li class="instagram"><a href="https://www.instagram.com/print.cad/" target="_blank">Instagram</a></li>
        <li class="whats"><a href="https://api.whatsapp.com/send?phone=5521971385918" target="_blank">WhatsApp</a></li>
        <li class="email"><a href="mailto:impressao.printcadcopias@gmail.com">E-mail</a></li>
    </ul>
</section>